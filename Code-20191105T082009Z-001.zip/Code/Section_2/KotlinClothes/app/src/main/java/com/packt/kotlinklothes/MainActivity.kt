package com.packt.kotlinklothes

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        var outfit = OutfitBuilder()
            .setShoes(Shoes("boot", Color.BLACK))
            .setShirt(Shirt("dress shirt", Color.GREEN))
            .setPants(Pants("jeans", Color.BLUE))
                .build()

        var outfit2 = OutfitBuilder()
            .addClothing(Shirt("tank top", Color.WHITE))
            .addClothing(Shoes("nike air", Color.YELLOW))
            .addClothing(Pants("shorts", Color.BLUE))
            .build()

        var outfit3 = Outfit(shoes = Shoes("styleA", Color.RED), pants = Pants("khakis", Color.WHITE))
    }
}
