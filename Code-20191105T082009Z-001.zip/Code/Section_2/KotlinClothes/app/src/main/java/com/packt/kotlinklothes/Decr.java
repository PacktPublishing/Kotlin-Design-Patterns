package com.packt.kotlinklothes;

public class Decr {

    int d = 9;
    Decr left;

    public Decr(Decr left) {
        this.left = left;
    }

    public void decr() {
        if (--d < 0) {
            d = 9;
            if (left != null) {
                left.decr();
            }
        }
    }

    public int c() {
        return (left == null) ? d : (d + 10 * left.c());
    }

    public static void main(String[] args) {
        Decr[] ds = new Decr[3];
        ds[2] = new Decr(null);
        ds[1] = new Decr(ds[2]);
        ds[0] = new Decr(ds[1]);
        for (int i = 0; i < 100; i++) {
            ds[0].decr();
        }
        for (int i = 2; i >= 0; i--) {
            System.out.println("ds[" + i + "]: " + ds[i].c());
        }
    }

}
