package com.packt.kotlinklothes

import android.graphics.Color

class Outfit(var shirt: Shirt = PlainWhiteShirt, var pants: Pants = Pants("jeans", Color.BLUE), var shoes: Shoes = Shoes("boot", Color.BLACK))