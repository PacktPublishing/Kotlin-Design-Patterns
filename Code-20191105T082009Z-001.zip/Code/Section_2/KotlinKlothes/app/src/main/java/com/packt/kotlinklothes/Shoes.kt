package com.packt.kotlinklothes

class Shoes(var style: String, var color: Int): Clothing