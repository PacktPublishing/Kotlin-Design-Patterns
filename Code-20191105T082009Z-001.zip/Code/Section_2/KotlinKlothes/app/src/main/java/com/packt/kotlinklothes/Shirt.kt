package com.packt.kotlinklothes

open class Shirt(var style: String, var color: Int): Clothing