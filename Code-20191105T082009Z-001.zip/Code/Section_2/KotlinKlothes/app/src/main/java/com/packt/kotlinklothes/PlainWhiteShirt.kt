package com.packt.kotlinklothes

import android.graphics.Color

object PlainWhiteShirt: Shirt(style = "t-shirt", color = Color.WHITE)