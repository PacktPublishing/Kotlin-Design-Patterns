package com.packt.kotlinklothes

class Pants(var style: String, var color: Int): Clothing