package com.packt.kotlinklothes

interface Clothing {
}