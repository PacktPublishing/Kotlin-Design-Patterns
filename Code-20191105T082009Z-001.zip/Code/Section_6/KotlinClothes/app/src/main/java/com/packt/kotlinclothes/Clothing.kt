package com.packt.kotlinclothes

interface Clothing