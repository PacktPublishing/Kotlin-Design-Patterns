package com.packt.kotlinclothes

class OutfitWithPromotion(val outfit: Outfit, var promo: String) {

    fun changePromotion(newPromo: String) {
        promo = newPromo
    }

}