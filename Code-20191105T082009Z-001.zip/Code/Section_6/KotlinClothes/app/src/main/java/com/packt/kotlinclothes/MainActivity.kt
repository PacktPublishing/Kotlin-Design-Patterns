package com.packt.kotlinclothes

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var outfit = OutfitBuilder()
                            .setShoes(Shoes("boot", Color.GRAY))
                            .setShirt(Shirt("dress shirt", Color.GREEN))
                            .setPants(Pants("jeans", Color.BLUE))
                            .build()


        var outfit2 = OutfitBuilder()
            .addClothing(Shirt("t shirt", Color.BLUE))
            .addClothing(Pants("jeans", Color.BLACK))
            .build()

        var outfit3 = Outfit(pants = Pants("dress pants", Color.BLACK),
            shoes = Shoes("sneaker", Color.YELLOW))

        ShoppingCart.add(outfit)
        ShoppingCart.checkout()


        ShoppingCartClassic.get()?.addOutfit(outfit2)
        ShoppingCartClassic.get()?.addOutfit(outfit3)

        ShoppingCartClassic.get()?.checkout()

        val summerOutfit = OutfitFactory.getOutfit(Style.SUMMER)
        val fallOutfit = OutfitFactory.getFallOutfit()

        val newItem = OutfitWithPromotion(fallOutfit, "15% off")

        label.text = "Item ${newItem.outfit.shirt.style} is now ${newItem.promo}"

        val currOutfit = CurrentSeason().getOutfitForCurrentSeason()
    }
}
