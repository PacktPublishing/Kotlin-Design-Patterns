package com.packt.kotlinclothes

class Summer : Season() {

    override fun getOutfit(): Outfit {
        return if (CurrentSeason.currentSeason == "summer") {
            OutfitFactory.getSummerOutfit()
        } else {
            next()
        }
    }

    override fun next(): Outfit = Sport().getOutfit()
}