package com.packt.kotlinclothes

import android.graphics.Color

object OutfitFactory {

    fun getOutfit(style: Style): Outfit = when (style) {

        Style.SUMMER -> Outfit(
            Shirt("tank top", Color.WHITE),
            Pants("shorts", Color.BLACK),
            Shoes("crocs", Color.BLUE))

        Style.FALL -> Outfit(
            pants = Pants("khaki", Color.BLACK),
            shoes = Shoes("boot", Color.DKGRAY),
            shirt = Shirt("sweater", Color.GRAY))

        Style.SPORT -> Outfit(
            shirt = Shirt("t-shirt", Color.BLUE),
            pants = Pants("training shorts", Color.RED),
            shoes = Shoes("sneakers", Color.GREEN)
        )
    }

    fun getSummerOutfit() = Outfit(
            Shirt("tank top", Color.WHITE),
            Pants("shorts", Color.BLACK),
            Shoes("slippers", Color.YELLOW))


    fun getFallOutfit() = Outfit(
            pants = Pants("khaki", Color.BLACK),
            shoes = Shoes("boot", Color.DKGRAY),
            shirt = Shirt("sweater", Color.GRAY))


    fun getSportOutfit() = Outfit(
            shirt = Shirt("t-shirt", Color.BLUE),
            pants = Pants("training shorts", Color.RED),
            shoes = Shoes("sneakers", Color.GREEN))

}