package com.packt.kotlinclothes

abstract class Season {
    abstract fun getOutfit(): Outfit
    abstract fun next(): Outfit
}