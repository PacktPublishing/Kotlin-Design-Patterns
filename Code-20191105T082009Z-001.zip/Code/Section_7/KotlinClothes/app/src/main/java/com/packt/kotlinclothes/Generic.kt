package com.packt.kotlinclothes

class Generic : Season() {
    override fun getOutfit() = Outfit()

    override fun next(): Outfit = Generic().getOutfit()
}