package com.packt.kotlinclothes

class CurrentSeason {

    companion object {
        const val currentSeason: String = "fall"
    }

    fun getOutfitForCurrentSeason() = Fall().getOutfit()

}