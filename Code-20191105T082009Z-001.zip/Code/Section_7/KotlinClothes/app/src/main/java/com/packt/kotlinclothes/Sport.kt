package com.packt.kotlinclothes

class Sport : Season() {
    override fun getOutfit(): Outfit {
        return if (CurrentSeason.currentSeason == "sport") {
            OutfitFactory.getSportOutfit()
        } else {
            next()
        }
    }

    override fun next(): Outfit = Fall().getOutfit()
}