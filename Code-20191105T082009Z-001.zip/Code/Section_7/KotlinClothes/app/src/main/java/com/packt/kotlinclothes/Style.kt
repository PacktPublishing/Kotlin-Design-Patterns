package com.packt.kotlinclothes

enum class Style {
    SUMMER, FALL, SPORT
}