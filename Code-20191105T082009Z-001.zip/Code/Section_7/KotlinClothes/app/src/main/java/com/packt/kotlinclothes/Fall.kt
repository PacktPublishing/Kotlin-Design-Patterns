package com.packt.kotlinclothes

class Fall : Season() {

    override fun getOutfit(): Outfit {
        return if (CurrentSeason.currentSeason == "fall") {
            OutfitFactory.getFallOutfit()
        } else {
            next()
        }
    }

    override fun next(): Outfit = Summer().getOutfit()

}