package com.packt.kotlinclothes

interface OnShoppingCartChangedListener {
    fun onOutfitAdded(outfit: Outfit, numItems: Int)
    fun onOutfitRemoved(outfit: Outfit, numItems: Int)
}