package com.packt.kotlinclothes

class ShoppingCartClassic {

    private val outfits: ArrayList<Outfit> = ArrayList()

    companion object {

        private var instance: ShoppingCartClassic? = null

        fun get(): ShoppingCartClassic? {
            if (instance == null) {
                instance = ShoppingCartClassic()
            }
            return instance
        }
    }

    fun addOutfit(outfit: Outfit) {
        outfits.add(outfit)
    }

    fun checkout() {
        //todo: implement me!
    }
}