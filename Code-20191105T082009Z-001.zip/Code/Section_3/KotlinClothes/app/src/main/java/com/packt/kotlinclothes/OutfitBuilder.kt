package com.packt.kotlinclothes

class OutfitBuilder {

    lateinit var shirt: Shirt
    lateinit var pants: Pants
    lateinit var shoes: Shoes

    var clothing = ArrayList<Clothing>()

    fun setShirt(shirt: Shirt): OutfitBuilder {
        this.shirt = shirt
        return this
    }

    fun setPants(pants: Pants): OutfitBuilder {
        this. pants = pants
        return this
    }

    fun setShoes(shoes: Shoes): OutfitBuilder {
        this.shoes = shoes
        return this
    }

    fun addClothing(clothingItem: Clothing): OutfitBuilder {
        clothing.add(clothingItem)
        return this
    }

    fun build(): Outfit {
        //do some checks

        clothing.forEach {
            if (it !is Shirt) {
                //do something
            }
        }

        return Outfit(shirt, pants, shoes)
    }

}