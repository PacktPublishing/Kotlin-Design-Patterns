package com.packt.kotlinclothes

open class Shirt(var style: String, var color: Int): Clothing