package com.packt.kotlinclothes

object ShoppingCart {

    private val outfits = ArrayList<Outfit>()

    fun add(outfit: Outfit) {
        outfits.add(outfit)
    }

    fun checkout() { }
}