package com.packt.kotlinclothes

open class Pants(var style: String, var color: Int): Clothing