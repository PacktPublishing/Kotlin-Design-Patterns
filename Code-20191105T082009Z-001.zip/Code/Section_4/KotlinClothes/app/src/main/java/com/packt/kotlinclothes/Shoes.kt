package com.packt.kotlinclothes

class Shoes(var style: String, var color: Int): Clothing